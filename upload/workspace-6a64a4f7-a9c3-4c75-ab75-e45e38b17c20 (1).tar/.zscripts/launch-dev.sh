#!/bin/bash
# Persistent dev launcher — direct redirect (NO tee) to avoid broken-pipe hangs.
# Survives the tool-call reaper: plain `&` + disown -> orphaned to init (tini).
cd /home/z/my-project
export NODE_OPTIONS="--max-old-space-size=1536"
bash -c 'bun run scripts/ensure-env.ts && exec ./node_modules/.bin/next dev -p 3000 > dev.log 2>&1' &
disown
echo "dev launched pid $!"
