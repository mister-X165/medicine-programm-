// СППВР v2.0 — Multimodal Analysis Pipeline API
// POST /api/cases/[id]/analyze
// Enhanced 10-step pipeline:
//   0. NEW (v2.1): Consent gate — refuse to run AI analysis unless the case
//      has an active `ai_analysis` consent (ФЗ-152 ст. 5 / ст. 9).
//   1. NER from discharge summaries
//   2. Genetic variant interpretation
//   3. Medical image analysis (VLM)
//   4. RAG recommendation matching
//   5. Pharmacogenomic contraindication cross-check
//   6. DDI check (drug-drug interactions)
//   7. ICD-10 code suggestions
//   8. Clinical pathway matching
//   9. Structured conclusion generation
//  10. Save all results (increment version, save previous to AnalysisVersion)

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  llmChat,
  parseJSON,
  vlmAnalyzeImage,
  getActiveProvider,
} from "@/lib/ai-service";
import {
  extractEntitiesFromDischarge,
  interpretGeneticVariants,
  analyzeMedicalImage,
} from "@/lib/file-parsers";
import { searchRecommendations, crossCheckTherapy, checkDrugInteractions, matchClinicalPathways, suggestICD10Codes } from "@/lib/rag";
import { readFileSync, fileToBase64DataUrl } from "@/lib/storage";
import { logger } from "@/lib/logger";
import { safeJsonParse } from "@/lib/utils";
import { requireAuth } from "@/lib/auth";
import { appendAudit } from "@/lib/audit";
import type {
  Entity,
  Mutation,
  Citation,
  ConclusionSection,
  DDIAlert,
  ICD10CodeMatch,
  ClinicalPathwayMatch,
} from "@/lib/types";

export const dynamic = "force-dynamic";
export const maxDuration = 600;

// v2.7.2 (audit fix): LLM возвращает clinicalSignificance произвольной строкой —
// нормализуем к строгому union типа Mutation.
const SIGNIFICANCE_VALUES: ReadonlySet<string> = new Set([
  "pathogenic", "likely_pathogenic", "vus", "likely_benign", "benign",
]);
function normalizeSignificance(value: string): Mutation["clinicalSignificance"] {
  const v = (value || "").toLowerCase().trim().replace(/[\s-]+/g, "_");
  if (SIGNIFICANCE_VALUES.has(v)) return v as Mutation["clinicalSignificance"];
  if (v.includes("pathogen")) return "likely_pathogenic";
  if (v.includes("benign")) return "likely_benign";
  return "vus";
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id: caseId } = await params;

  // ─── OUTER TRY/CATCH ──────────────────────────────────────────────────
  // The analysis pipeline has many steps (NER, genetic interpretation, VLM,
  // RAG, DDI, ICD-10, pathways, LLM conclusion). Each step is individually
  // wrapped in try/catch, but this OUTER handler is the last line of defense:
  // if ANY uncaught error bubbles up, we:
  //   1. Reset the case status from "analyzing" back to its previous state
  //      (so it's not stuck in "analyzing" forever).
  //   2. Return a clear 500 error with the error message (not a bare crash).
  //   3. Log the full error + stack for debugging.
  try {
    return await analyzeCase(req, caseId);
  } catch (error) {
    logger.error("analysis", "Unhandled error in analyze pipeline", {
      caseId,
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
    });
    // Reset case status so it's not stuck in "analyzing"
    try {
      await db.case.update({
        where: { id: caseId },
        data: { status: "uploaded" },
      });
    } catch {
      // ignore — the case might not exist anymore
    }
    const msg = error instanceof Error ? error.message : "Internal server error";
    return NextResponse.json(
      {
        error: `Анализ не удалось завершить: ${msg}. Система восстановлена — случай доступен для повторного анализа.`,
        caseId,
      },
      { status: 500 },
    );
  }
}

async function analyzeCase(req: Request, caseId: string) {
  // ─── Step 0: Authentication + Consent gate (ФЗ-152) ───────────────────
  let session;
  try {
    session = await requireAuth(req);
  } catch {
    return NextResponse.json({ error: "Authentication required" }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const forceManual = body?.manual === true;

  const found = await db.case.findUnique({
    where: { id: caseId },
    include: { documents: true, doctor: true, consents: true },
  });
  if (!found) {
    return NextResponse.json({ error: "Case not found" }, { status: 404 });
  }

  // Authorization: only the case's owner or an admin may analyze it
  if (found.doctorId !== session.doctorId && session.role !== "admin") {
    return NextResponse.json(
      { error: "You are not authorized to analyze this case" },
      { status: 403 },
    );
  }

  // Consent gate — `ai_analysis` consent must be present, granted, and not
  // expired. In manual mode we still log the attempt but allow it, because
  // no AI processing of PHI occurs.
  const aiConsent = found.consents.find(
    (c) => c.consentType === "ai_analysis" && c.granted,
  );
  const consentExpired =
    aiConsent?.validUntil != null && new Date(aiConsent.validUntil) < new Date();

  if (!aiConsent) {
    return NextResponse.json(
      {
        error:
          "Patient consent for AI analysis is missing. Obtain and record the `ai_analysis` consent before running the analysis pipeline.",
        errorCode: "CONSENT_MISSING",
        consentType: "ai_analysis",
      },
      { status: 403 },
    );
  }
  if (consentExpired) {
    return NextResponse.json(
      {
        error:
          "Patient consent for AI analysis has expired. Re-obtain consent before running the analysis pipeline.",
        errorCode: "CONSENT_EXPIRED",
        consentType: "ai_analysis",
        expiredAt: aiConsent.validUntil,
      },
      { status: 403 },
    );
  }

  const provider = await getActiveProvider();
  const aiAvailable = provider !== "none" && !forceManual;

  await db.case.update({ where: { id: caseId }, data: { status: "analyzing" } });

  const entities: Entity[] = [];
  const mutations: Mutation[] = [];
  const citations: Citation[] = [];
  const imageFindings: Array<{
    documentId: string;
    description: string;
    regionOfInterest?: string;
    measurements?: string;
    suspicion: string;
  }> = [];
  let dischargeSummary = "";

  const discharges = found.documents.filter((d) => d.fileType === "discharge");
  const genetics = found.documents.filter((d) => d.fileType === "genetic");
  const images = found.documents.filter((d) => d.fileType === "image");

  // ─── Step 1: NER from discharge summaries ─────────────────────────────
  for (const doc of discharges) {
    if (aiAvailable) {
      const result = await extractEntitiesFromDischarge(doc.deidContent);
      if (result) {
        for (const e of result.entities) {
          entities.push({ type: e.type as Entity["type"], value: e.value, context: e.context });
          citations.push({
            claim: e.value,
            source: "discharge",
            documentId: doc.id,
            fragment: e.context || doc.deidContent.slice(0, 200),
            location: `Document: ${doc.fileName}`,
          });
        }
        for (const m of result.mutations) {
          mutations.push({
            gene: m.gene,
            variant: m.variant,
            interpretation: m.interpretation,
            clinicalSignificance: normalizeSignificance(m.clinicalSignificance),
          });
        }
        if (result.summary) dischargeSummary += result.summary + "\n\n";
      }
    } else {
      citations.push({
        claim: "Document loaded in manual mode (AI unavailable)",
        source: "discharge",
        documentId: doc.id,
        fragment: doc.deidContent.slice(0, 200),
        location: `Document: ${doc.fileName}`,
      });
    }
  }

  // ─── Step 2: Genetic variant interpretation ───────────────────────────
  for (const doc of genetics) {
    if (aiAvailable) {
      const interp = await interpretGeneticVariants(doc.deidContent);
      if (interp) {
        for (const m of interp) {
          mutations.push(m);
          citations.push({
            claim: `${m.gene}: ${m.variant}`,
            source: "genetic",
            documentId: doc.id,
            fragment: `${m.interpretation} (${m.clinicalSignificance})`,
            location: `Document: ${doc.fileName}`,
          });
        }
      }
    } else {
      try {
        const meta = JSON.parse(doc.extractedMeta);
        if (meta.variants) {
          for (const v of meta.variants) {
            mutations.push({
              gene: v.id || v.chrom || "—",
              variant: `${v.ref}>${v.alt} (pos ${v.pos})`,
              interpretation: "Variant from genetic report (requires manual interpretation)",
              clinicalSignificance: "vus",
            });
          }
        }
      } catch { /* ignore */ }
    }
  }

  // ─── Step 3: Medical image analysis (VLM) ────────────────────────────
  for (const doc of images) {
    if (aiAvailable && doc.storagePath) {
      try {
        const imgBuffer = readFileSync(doc.storagePath);
        if (imgBuffer) {
          const dataUrl = fileToBase64DataUrl(imgBuffer, doc.mimeType);
          const finding = await analyzeMedicalImage(
            dataUrl,
            `${found.diagnosisHint || ""} ${dischargeSummary}`.trim(),
          );
          if (finding) {
            imageFindings.push({
              documentId: doc.id,
              description: finding.findings,
              regionOfInterest: finding.regionOfInterest,
              measurements: finding.measurements,
              suspicion: finding.suspicion,
            });
            citations.push({
              claim: finding.findings.slice(0, 120),
              source: "image",
              documentId: doc.id,
              fragment: `${finding.regionOfInterest}. ${finding.measurements}. Suspicion: ${finding.suspicion}`,
              location: `Image: ${doc.fileName}`,
            });
          }
        }
      } catch (e) {
        logger.error("analysis", "Image analysis error", { error: e instanceof Error ? e.message : String(e) });
      }
    } else if (doc.storagePath) {
      imageFindings.push({
        documentId: doc.id,
        description: "Image loaded (analysis unavailable in manual mode)",
        suspicion: "low",
      });
    }
  }

  // ─── Step 4: RAG — ПРЯМОЙ РАЗБОР РЕПОЗИТОРИЯ КР МИНЗДРАВА ПО ТЕМЕ ────
  // v4.2: searchRecommendations подключается НАПРЯМУЮ к репозиторию КР
  // Минздрава РФ (cr.minzdrav.gov.ru) и разбирает его по теме кейса
  // (диагноз + выписка + гены): поиск КР → полные тексты → парсинг всех
  // разделов → фрагменты, релевантные теме. Локальная база — только офлайн-фолбэк.
  const recommendations = await searchRecommendations(
    mutations,
    `${found.diagnosisHint || ""} ${dischargeSummary}`.trim(),
  );
  for (const r of recommendations.slice(0, 5)) {
    citations.push({
      claim: r.title,
      source: "recommendation",
      documentId: undefined,
      fragment: r.content,
      location: `${r.source} (evidence: ${r.evidenceLevel || "—"})`,
    });
  }

  // ─── Step 4.5: Web RAG — ПРЯМОЙ РАЗБОР КР МИНЗДРАВА ПО ТЕМЕ КЕЙСА ──
  // v4.2: ИИ напрямую подключается к официальному репозиторию КР Минздрава
  // РФ (cr.minzdrav.gov.ru) и разбирает его по теме кейса: поиск КР →
  // полные тексты → парсинг ВСЕХ разделов (диагностика, лечение, алгоритмы
  // Прил. Б, шкалы Прил. Г) → отбор фрагментов, релевантных теме. Запрос
  // санитизируется (PHI исключается) ДО выхода в сеть. Найденные фрагменты
  // подаются LLM в Step 9 и добавляются в цитаты. BEST-EFFORT: при офлайне
  // анализ продолжается с локальной базой (персистентный кэш сохраняет тексты).
  let webRagContext = "";
  let webRagResults: Array<{
    title: string;
    url: string;
    source: string;
    snippet: string;
    relevanceScore: number;
  }> = [];
  try {
    const { runWebRag, buildWebRagContext } = await import("@/lib/web-rag");
    const medicationsForWeb = entities
      .filter((e) => e.type === "medication")
      .map((e) => e.value);
    // ICD-10 подсказки для поиска КР: коды МКБ из сущностей-диагнозов
    // (формат вида E11.9 в значении сущности)
    const icd10Hints = entities
      .filter((e) => e.type === "diagnosis" || e.type === "other")
      .map((e) => e.value)
      .flatMap((v) => (v.match(/[A-TV-Z][0-9]{2}(?:\.[0-9]{1,2})?/g) ?? []))
      .slice(0, 3);
    const webRagResponse = await runWebRag({
      diagnosisHint: found.diagnosisHint,
      dischargeSummary: dischargeSummary.slice(0, 3000),
      mutations,
      medications: medicationsForWeb,
      entities,
      maxResults: 6,
      enableContentFetch: true,
      icd10Codes: icd10Hints,
    });
    webRagResults = webRagResponse.results;
    webRagContext = buildWebRagContext(webRagResponse.results, webRagResponse.sanitizedQuery);

    // Add web RAG results as citations so they appear in the analysis UI.
    // v4.2: дедупликация — рекомендации (Step 4) теперь тоже приходят из
    // репозитория Минздрава; не дублируем цитату уже процитированной КР
    for (const wr of webRagResponse.results) {
      const alreadyCited = citations.some(
        (c) => wr.url && (c.location?.includes(wr.url) || c.claim === wr.title),
      );
      if (alreadyCited) continue;
      citations.push({
        claim: wr.title,
        source: "web_rag",
        documentId: undefined,
        fragment: wr.contentExcerpt || wr.snippet || "",
        location: `${wr.source}: ${wr.url}`,
      });
    }

    logger.info("analysis", "Минздрав КР web RAG completed", {
      caseId,
      resultCount: webRagResponse.results.length,
      termsUsed: webRagResponse.sanitizedQuery.terms,
      removedPHI: webRagResponse.sanitizedQuery.removedPHI.length,
    });
  } catch (e) {
    logger.warn("analysis", "Web RAG failed (non-blocking)", {
      error: e instanceof Error ? e.message : String(e),
    });
  }

  // ─── Step 5: Pharmacogenomic contraindication cross-check ─────────────
  const therapyWarnings = await crossCheckTherapy(mutations, recommendations);
  for (const w of therapyWarnings) {
    citations.push({
      claim: w.message,
      source: "recommendation",
      documentId: undefined,
      fragment: `Type: ${w.type === "contraindication" ? "Contraindication" : w.type === "adjustment" ? "Dose adjustment" : "Warning"}`,
      location: `Cross-check: ${w.gene}`,
    });
  }

  // ─── Step 6: NEW — DDI check ──────────────────────────────────────────
  let ddiAlerts: DDIAlert[] = [];
  try {
    // Extract medication names from entities
    const medications = entities
      .filter((e) => e.type === "medication")
      .map((e) => e.value);

    // Also get from discharge summary
    if (dischargeSummary && medications.length === 0) {
      medications.push(...extractMedNamesFromText(dischargeSummary));
    }

    ddiAlerts = await checkDrugInteractions(medications, mutations);
  } catch (e) {
    logger.warn("analysis", "DDI check error", { error: e instanceof Error ? e.message : String(e) });
  }

  // ─── Step 7: NEW — ICD-10 code suggestions ────────────────────────────
  let icd10Suggestions: ICD10CodeMatch[] = [];
  try {
    icd10Suggestions = await suggestICD10Codes(
      found.diagnosisHint || dischargeSummary,
      entities,
    );
  } catch (e) {
    logger.warn("analysis", "ICD-10 suggestion error", { error: e instanceof Error ? e.message : String(e) });
  }

  // ─── Step 8: NEW — Clinical pathway matching ──────────────────────────
  let pathwayMatches: ClinicalPathwayMatch[] = [];
  try {
    pathwayMatches = await matchClinicalPathways(
      found.diagnosisHint || dischargeSummary,
      icd10Suggestions,
      mutations,
    );
  } catch (e) {
    logger.warn("analysis", "Pathway matching error", { error: e instanceof Error ? e.message : String(e) });
  }

  // ─── Step 9: Structured conclusion generation ─────────────────────────
  let sections: ConclusionSection[] = [];
  let conclusion = "";
  let confidence: Record<string, number> = {};

  if (aiAvailable) {
    const system = `Ты — мультимодальная медицинская консультационная платформа СППВР. Ты выступаешь как виртуальный консилиум специалистов: терапевт, онколог, кардиолог, фармаколог, эндокринолог, невролог, инфекционист, клинический генетик, лабораторный диагност, специалист по визуализации и клиническим путям.

Твоя задача — на основе предоставленных фактов сформировать структурированное клиническое заключение с КОНКРЕТНЫМ диагнозом и КОНКРЕТНЫМИ рекомендациями по диагностике и лечению.

КРИТИЧЕСКИЕ ПРАВИЛА:
1. Опирайся ТОЛЬКО на предоставленные факты. Не придумывай данные, которых нет в документах.
2. ДИАГНОЗ ДОЛЖЕН БЫТЬ КОНКРЕТНЫМ — не общие рассуждения, а названное заболевание с кодом МКБ-10. Например: "Сахарный диабет 2 типа, декомпенсированный (E11.9)", а не "у пациента нарушения углеводного обмена". Если данных недостаточно для точного диагноза — укажи наиболее вероятный дифференциальный диагноз с обоснованием.
3. Для каждого препарата ОБЯЗАТЕЛЬНО указывай: МНН, доза, путь введения, кратность, длительность. Пример: "Метформин 1000 мг перорально 2 раза/сутки, длительно".
4. Учитывай даты анализов — если анализ старый (>3 месяцев), укажи необходимость повторного исследования.
5. Учитывай лекарственные взаимодействия (DDI) и фармакогеномные особенности.
6. ПРИОРИТЕТ ИСТОЧНИКОВ: если в контексте приведены фрагменты официальных КЛИНИЧЕСКИХ РЕКОМЕНДАЦИЙ МИНЗДРАВА РФ (cr.minzdrav.gov.ru) — формулируй диагностику и лечение ИМЕННО по ним и ссылайся на них как «КР Минздрава РФ [код/версия]». Прочие источники (CPIC, ESC, NCCN) упоминай только для дополнительной информации.
7. Соблюдай доказательную медицину.

ФОРМАТ ОТВЕТА — текст с разделами. Каждый раздел начинается со строки "### НАЗВАНИЕ_РАЗДЕЛА" (символ решётка, пробел, название заглавными буквами). Содержание раздела — на следующих строках до следующего "###".

ОБЯЗАТЕЛЬНЫЕ РАЗДЕЛЫ (используй ровно эти названия):

### КЛИНИЧЕСКАЯ КАРТИНА
Опиши основные симптомы, анамнез, жалобы из выписки. Упомяни даты ключевых событий.

### ДИАГНОЗ
СФОРМУЛИРУЙ КОНКРЕТНЫЙ ОСНОВНОЙ ДИАГНОЗ с кодом МКБ-10. Формат ОБЯЗАТЕЛЬНЫЙ:
  Основной диагноз: [название заболевания] ([код МКБ-10])
  Стадия/форма: [если применимо]
  Сопутствующие: [если есть]
  Осложнения: [если есть]
Если диагноз неоднозначен — укажи наиболее вероятный и его обоснование (1-2 предложения). НЕ ОГРАНИЧИВАЙСЯ общими формулировками вроде "нарушение обмена веществ" — назови конкретную нозологию.

### ГЕНЕТИЧЕСКИЙ ПРОФИЛЬ
Перечисли мутации с интерпретацией. Если нет — напиши "Генетических данных не предоставлено."

### РЕКОМЕНДУЕМАЯ ТЕРАПИЯ
Каждый препарат отдельной строкой в формате:
- [МНН] [доза] [путь введения] [кратность] [длительность] — [обоснование] (доказательность: [A/B/C], источник: [...])
Например:
- Метформин 1000 мг перорально 2 раза/сутки длительно — препарат первой линии при СД2 (доказательность: A, источник: КР Минздрава РФ 622_5 «Сахарный диабет 2 типа»)
Если препаратов несколько — перечисли все.

### АЛЬТЕРНАТИВНЫЕ РЕЖИМЫ
Альтернативные схемы терапии с обоснованием.

### ПРОТИВОПОКАЗАНИЯ И ПРЕДУПРЕЖДЕНИЯ
Абсолютные и относительные противопоказания, предупреждения.

### ЛЕКАРСТВЕННЫЕ ВЗАИМОДЕЙСТВИЯ (DDI)
Перечисли выявленные взаимодействия с рекомендациями по ведению. Если нет — "Выявленных взаимодействий нет."

### МОНИТОРИНГ И КОНТРОЛЬ
Что контролировать, с какой частотой, целевые значения. Учитывай сроки годности анализов (например, "контроль HbA1c через 3 месяца").

### КЛИНИЧЕСКИЕ ПУТИ
Соответствие клиническим протоколам.

### РЕЗЮМЕ
Краткое summary заключения (3-5 предложений). НАЧИНАЙ С КОНКРЕТНОГО ДИАГНОЗА: "У пациента [диагноз с МКБ-10]. Назначена терапия [...]. Прогноз [...]."

### УВЕРЕННОСТЬ
Укажи оценки уверенности от 0 до 1 в формате:
diagnosis: 0.X
therapy: 0.X
prognosis: 0.X
overall: 0.X

ВАЖНО: отвечай ТОЛЬКО на русском языке. Не используй markdown-обёртку. Начинай сразу с "### КЛИНИЧЕСКАЯ КАРТИНА".`;

    const contextParts: string[] = [];


    // -- Patient EMR context enrichment --
    // If the case is linked to a patient record, include the patient's
    // medical data (allergies, medications, problems, vitals, labs) as
    // additional context for the AI.
    if (found.patientId) {
      try {
        const patientRecord = await db.patient.findUnique({
          where: { id: found.patientId },
          include: {
            vitalSigns: { orderBy: { recordedAt: 'desc' }, take: 10 },
            medications: { where: { status: 'active' }, take: 20 },
            problems: { where: { status: { in: ['active', 'chronic', 'uncontrolled'] } } },
            labResults: { orderBy: { collectedAt: 'desc' }, take: 30 },
            visits: { orderBy: { scheduledAt: 'desc' }, take: 5 },
          },
        });
        if (patientRecord) {
          const emrParts: string[] = [];
          emrParts.push('Patient: ' + patientRecord.patientToken + ', sex: ' + (patientRecord.sex || 'N/A') + ', blood: ' + (patientRecord.bloodType || 'N/A'));
          if (patientRecord.birthYear && patientRecord.birthYear > 1850) {
            emrParts.push('Age: ' + (new Date().getFullYear() - patientRecord.birthYear));
          }
          const allergiesArr = safeJsonParse<Array<{ allergen?: string; reaction?: string }>>(patientRecord.allergies, []);
          if (allergiesArr.length > 0) {
            emrParts.push('Allergies: ' + allergiesArr.map((a) => a.allergen + (a.reaction ? ' (' + a.reaction + ')' : '')).join(', '));
          }
          const activeMeds = patientRecord.medications;
          if (activeMeds.length > 0) {
            emrParts.push('Active meds: ' + activeMeds.map((m) => m.drugName + ' ' + m.dosage + ' ' + m.route + ' ' + m.frequency).join(', '));
          }
          if (patientRecord.problems.length > 0) {
            emrParts.push('Problems: ' + patientRecord.problems.map((p) => p.title + (p.icd10 ? ' (' + p.icd10 + ')' : '') + ' [' + p.severity + ']').join(', '));
          }
          const latestVitals = patientRecord.vitalSigns[0];
          if (latestVitals) {
            const vParts: string[] = [];
            if (latestVitals.systolicBP) vParts.push('BP ' + latestVitals.systolicBP + '/' + latestVitals.diastolicBP);
            if (latestVitals.heartRate) vParts.push('HR ' + latestVitals.heartRate);
            if (latestVitals.temperature) vParts.push('T ' + latestVitals.temperature);
            if (latestVitals.oxygenSaturation) vParts.push('SpO2 ' + latestVitals.oxygenSaturation + '%');
            if (vParts.length > 0) emrParts.push('Vitals: ' + vParts.join(', '));
          }
          const recentLabs = patientRecord.labResults.filter((l) => l.flag !== 'normal').slice(0, 10);
          if (recentLabs.length > 0) {
            emrParts.push('Abnormal labs: ' + recentLabs.map((l) => l.testName + ': ' + l.value + ' ' + l.unit + ' [' + l.flag + ']').join(', '));
          }
          contextParts.push('=== EMR PATIENT DATA ===\n' + emrParts.join('\n') + '\n=== END EMR DATA ===');
        }
      } catch (e) {
        logger.warn('analysis', 'Failed to load patient EMR context', { patientId: found.patientId, error: e instanceof Error ? e.message : String(e) });
      }
    }

if (mutations.length > 0) {
      contextParts.push(`Выявленные мутации:\n${mutations.slice(0, 10).map((m) => `- ${m.gene}: ${m.variant} (${m.clinicalSignificance}) — ${m.interpretation}`).join("\n")}`);
    }
    if (recommendations.length > 0) {
      contextParts.push(`Клинические рекомендации (RAG из локальной БД):\n${recommendations.slice(0, 5).map((r) => `- ${r.title}: ${r.content.slice(0, 300)} (источник: ${r.source}, доказательность: ${r.evidenceLevel || "—"})`).join("\n")}`);
    }
    if (therapyWarnings.length > 0) {
      contextParts.push(`Предупреждения:\n${therapyWarnings.map((w) => `- ${w.gene}: ${w.message}`).join("\n")}`);
    }
    if (ddiAlerts.length > 0) {
      contextParts.push(`Лекарственные взаимодействия (DDI):\n${ddiAlerts.map((a) => `- ${a.drug1} + ${a.drug2} (${a.severity}): ${a.description}\n  Механизм: ${a.mechanism}\n  Рекомендация: ${a.management}`).join("\n")}`);
    }
    if (icd10Suggestions.length > 0) {
      contextParts.push(`Коды МКБ-10 (предварительно):\n${icd10Suggestions.slice(0, 5).map((c) => `- ${c.code} — ${c.description} (уверенность: ${Math.round(c.confidence * 100)}%)`).join("\n")}`);
    }
    if (pathwayMatches.length > 0) {
      contextParts.push(`Клинические пути:\n${pathwayMatches.slice(0, 3).map((p) => `- ${p.name} (совпадение: ${Math.round(p.matchScore * 100)}%)`).join("\n")}`);
    }
    if (imageFindings.length > 0) {
      contextParts.push(`Данные визуализации:\n${imageFindings.map((f) => `- ${f.description}${f.measurements ? ` (размеры: ${f.measurements})` : ""}`).join("\n")}`);
    }
    if (entities.length > 0) {
      const diagnoses = entities.filter((e) => e.type === "diagnosis");
      const medications = entities.filter((e) => e.type === "medication");
      if (diagnoses.length > 0) {
        contextParts.push(`Диагнозы из выписки: ${diagnoses.map((e) => e.value).join(", ")}`);
      }
      if (medications.length > 0) {
        contextParts.push(`Препараты из выписки: ${medications.map((e) => e.value).join(", ")}`);
      }
    }

    const dischargeText = discharges.map((d) => d.deidContent).join("\n\n").slice(0, 4000);

    // Include web RAG context (official Минздрав РФ clinical recommendations)
    // as additional knowledge for the LLM. This is clearly delimited so the
    // model treats it as external evidence, not patient data.
    if (webRagContext) {
      contextParts.push(webRagContext);
    }

    const userMsg = dischargeText
      ? `ТЕКСТ ВЫПИСКИ (де-идентифицированный):\n${dischargeText}\n\nДАННЫЕ АНАЛИЗА:\n${contextParts.join("\n\n")}`
      : `ДАННЫЕ АНАЛИЗА:\n${contextParts.join("\n\n")}`;

    const raw = await llmChat(system, userMsg, { json: false, maxTokens: 8192 });
    if (raw && raw.trim().length > 0) {
      const parsedJson = parseJSON<{ sections?: ConclusionSection[]; conclusion?: string; confidence?: Record<string, number> }>(raw);
      if (parsedJson && Array.isArray(parsedJson.sections) && parsedJson.sections.length > 0) {
        sections = parsedJson.sections;
        conclusion = parsedJson.conclusion ?? "";
        confidence = parsedJson.confidence ?? {};
      } else {
        const parsed = parsePlainTextConclusion(raw);
        sections = parsed.sections;
        conclusion = parsed.conclusion;
        confidence = parsed.confidence;
      }
    }

    if (sections.length === 0 && !conclusion) {
      conclusion = buildFallbackConclusion(found, mutations, recommendations, therapyWarnings, ddiAlerts);
      sections = buildFallbackSections(mutations, recommendations, therapyWarnings, ddiAlerts, icd10Suggestions, pathwayMatches, citations);
    }
  } else {
    conclusion = `Manual mode (AI core unavailable). Documents loaded: ${found.documents.length}. Variants found: ${mutations.length}. Manual analysis required.`;
    sections = buildFallbackSections(mutations, recommendations, therapyWarnings, ddiAlerts, icd10Suggestions, pathwayMatches, citations);
    confidence = { diagnosis: 0, therapy: 0, prognosis: 0 };
  }

  // ─── Step 10: Save all results (versioned) ────────────────────────────
  // Get existing analysis to check version
  const existingAnalysis = await db.analysisResult.findUnique({ where: { caseId } });
  let newVersion = 1;

  if (existingAnalysis) {
    // Save current state as a version snapshot before overwriting
    const currentVersion = existingAnalysis.version || 1;
    newVersion = currentVersion + 1;

    await db.analysisVersion.create({
      data: {
        analysisId: existingAnalysis.id,
        version: currentVersion,
        snapshot: JSON.stringify({
          entities: existingAnalysis.entities,
          mutations: existingAnalysis.mutations,
          recommendations: existingAnalysis.recommendations,
          conclusion: existingAnalysis.conclusion,
          sections: existingAnalysis.sections,
          confidence: existingAnalysis.confidence,
          citations: existingAnalysis.citations,
          imageFindings: existingAnalysis.imageFindings,
          ddiAlerts: existingAnalysis.ddiAlerts,
          icd10Suggestions: existingAnalysis.icd10Suggestions,
          pathwayMatches: existingAnalysis.pathwayMatches,
        }),
        changeNote: `Re-analysis (v${currentVersion} → v${newVersion})`,
        doctorId: session.doctorId,
      },
    });
  }

  // Update case ICD-10 codes
  if (icd10Suggestions.length > 0) {
    await db.case.update({
      where: { id: caseId },
      data: { icd10Codes: JSON.stringify(icd10Suggestions) },
    });
  }

  const analysis = await db.analysisResult.upsert({
    where: { caseId },
    create: {
      caseId,
      entities: JSON.stringify(entities),
      mutations: JSON.stringify(mutations),
      recommendations: JSON.stringify(recommendations),
      conclusion,
      sections: JSON.stringify(sections),
      confidence: JSON.stringify(confidence),
      citations: JSON.stringify(citations),
      imageFindings: JSON.stringify(imageFindings),
      ddiAlerts: JSON.stringify(ddiAlerts),
      icd10Suggestions: JSON.stringify(icd10Suggestions),
      pathwayMatches: JSON.stringify(pathwayMatches),
      version: newVersion,
    },
    update: {
      entities: JSON.stringify(entities),
      mutations: JSON.stringify(mutations),
      recommendations: JSON.stringify(recommendations),
      conclusion,
      sections: JSON.stringify(sections),
      confidence: JSON.stringify(confidence),
      citations: JSON.stringify(citations),
      imageFindings: JSON.stringify(imageFindings),
      ddiAlerts: JSON.stringify(ddiAlerts),
      icd10Suggestions: JSON.stringify(icd10Suggestions),
      pathwayMatches: JSON.stringify(pathwayMatches),
      version: newVersion,
    },
  });

  await db.case.update({ where: { id: caseId }, data: { status: "analyzed" } });

  await appendAudit({
    caseId,
    doctorId: session.doctorId,
    action: "analyze",
    details: JSON.stringify({
      aiAvailable,
      aiProvider: provider,
      entityCount: entities.length,
      mutationCount: mutations.length,
      recommendationCount: recommendations.length,
      warningCount: therapyWarnings.length,
      ddiAlertCount: ddiAlerts.length,
      icd10Count: icd10Suggestions.length,
      pathwayCount: pathwayMatches.length,
      webRagResultCount: webRagResults.length,
      version: newVersion,
      consentId: aiConsent?.id,
    }),
  });

  return NextResponse.json({
    analysis: {
      id: analysis.id,
      caseId,
      entities,
      mutations,
      recommendations,
      conclusion,
      sections,
      confidence,
      citations,
      imageFindings,
      therapyWarnings,
      ddiAlerts,
      icd10Suggestions,
      pathwayMatches,
      webRagResults,
      version: newVersion,
      aiAvailable,
      createdAt: analysis.createdAt.toISOString(),
      updatedAt: analysis.updatedAt.toISOString(),
    },
  });
}

// ─── Helper functions ────────────────────────────────────────────────────

function extractMedNamesFromText(text: string): string[] {
  const meds: string[] = [];
  const medPattern = /(?:препарат|лекарство|мнн|назначен|терапия|приём|инфузия)[:\s]+([А-ЯЁа-яёA-Z][А-ЯЁа-яёA-Z0-9\s\-]{2,40})/gi;
  let match;
  while ((match = medPattern.exec(text)) !== null) {
    meds.push(match[1].trim());
  }
  return meds;
}

function buildFallbackConclusion(
  found: { caseCode: string; diagnosisHint: string | null },
  mutations: Mutation[],
  recommendations: Array<{ title: string }>,
  warnings: Array<{ gene: string; message: string }>,
  ddiAlerts: DDIAlert[],
): string {
  const parts: string[] = [];
  parts.push(`Case ${found.caseCode}.`);
  if (found.diagnosisHint) parts.push(`Preliminary diagnosis: ${found.diagnosisHint}.`);
  parts.push(`Genetic variants found: ${mutations.length}.`);
  if (recommendations.length > 0) parts.push(`Clinical recommendations matched: ${recommendations.length}.`);
  if (warnings.length > 0) parts.push(`Contraindications/warnings: ${warnings.length}.`);
  if (ddiAlerts.length > 0) parts.push(`Drug interactions: ${ddiAlerts.length}.`);
  return parts.join(" ");
}

function buildFallbackSections(
  mutations: Mutation[],
  recommendations: Array<{ id: string; title: string; gene?: string; content: string; source: string; evidenceLevel?: string }>,
  warnings: Array<{ gene: string; message: string; type: string }>,
  ddiAlerts: DDIAlert[],
  icd10Suggestions: ICD10CodeMatch[],
  pathwayMatches: ClinicalPathwayMatch[],
  citations: Citation[],
): ConclusionSection[] {
  const sections: ConclusionSection[] = [];

  sections.push({
    title: "Genetic Profile",
    content: mutations.length > 0
      ? mutations.map((m) => `• ${m.gene}: ${m.variant} — ${m.interpretation} [${m.clinicalSignificance}]`).join("\n")
      : "No genetic variants identified.",
    confidence: mutations.length > 0 ? 0.7 : 0.3,
    citations: citations.filter((c) => c.source === "genetic"),
  });

  sections.push({
    title: "Clinical Recommendations (RAG)",
    content: recommendations.length > 0
      ? recommendations.slice(0, 5).map((r, i) => `${i + 1}. ${r.title} (${r.source})`).join("\n")
      : "No relevant recommendations found.",
    confidence: recommendations.length > 0 ? 0.8 : 0.2,
    citations: citations.filter((c) => c.source === "recommendation"),
  });

  sections.push({
    title: "Contraindications and Warnings",
    content: warnings.length > 0
      ? warnings.map((w) => `⚠ ${w.gene}: ${w.message}`).join("\n\n")
      : "No contraindications identified.",
    confidence: warnings.length > 0 ? 0.85 : 0.5,
    citations: [],
  });

  if (ddiAlerts.length > 0) {
    sections.push({
      title: "Drug-Drug Interactions (DDI)",
      content: ddiAlerts.map((a) => `⚠ ${a.drug1} + ${a.drug2} (${a.severity}): ${a.description.slice(0, 200)}`).join("\n\n"),
      confidence: 0.8,
      citations: [],
    });
  }

  if (icd10Suggestions.length > 0) {
    sections.push({
      title: "ICD-10 Codes",
      content: icd10Suggestions.slice(0, 10).map((c) => `${c.code} — ${c.description} (confidence: ${Math.round(c.confidence * 100)}%)`).join("\n"),
      confidence: icd10Suggestions[0]?.confidence ?? 0.5,
      citations: [],
    });
  }

  if (pathwayMatches.length > 0) {
    sections.push({
      title: "Clinical Pathways",
      content: pathwayMatches.slice(0, 5).map((p) => `• ${p.name} (match: ${Math.round(p.matchScore * 100)}%)`).join("\n"),
      confidence: pathwayMatches[0]?.matchScore ?? 0.5,
      citations: [],
    });
  }

  return sections;
}

function parsePlainTextConclusion(raw: string): {
  sections: ConclusionSection[];
  conclusion: string;
  confidence: Record<string, number>;
} {
  const sections: ConclusionSection[] = [];
  let conclusion = "";
  const confidence: Record<string, number> = {};

  // Strip markdown code fences if present
  let cleaned = raw.trim();
  const fence = cleaned.match(/```(?:json|markdown)?\s*([\s\S]*?)```/);
  if (fence) cleaned = fence[1].trim();

  const lines = cleaned.split(/\r?\n/);
  let currentTitle = "";
  let currentBody: string[] = [];

  const flush = () => {
    const content = currentBody.join("\n").trim();
    if (currentTitle && content) {
      const titleUpper = currentTitle.toUpperCase();
      if (titleUpper.includes("РЕЗЮМЕ") || titleUpper.includes("SUMMARY") || titleUpper.includes("SUMMERY")) {
        // v2.3.2: Если ещё не нашли раздел ДИАГНОЗ — используем РЕЗЮМЕ как conclusion.
        // Если ДИАГНОЗ уже найден — conclusion уже установлен, оставляем его.
        if (!conclusion) {
          conclusion = content;
        }
        sections.push({
          title: currentTitle,
          content,
          confidence: 0.7,
          citations: [],
        });
      } else if (titleUpper.includes("ДИАГНОЗ") || titleUpper.includes("DIAGNOSIS")) {
        // v2.3.2: ПРИОРИТЕТ — раздел ДИАГНОЗ — это и есть конкретный диагноз,
        // который показывается в "Заключении" в UI. Если уже было РЕЗЮМЕ —
        // ДИАГНОЗ перекрывает его (диагноз важнее summary).
        conclusion = content;
        sections.push({
          title: currentTitle,
          content,
          confidence: 0.85,
          citations: [],
        });
      } else if (titleUpper.includes("УВЕРЕННОСТ") || titleUpper.includes("CONFIDENCE") || titleUpper.includes("УВЕРЕННОСТЬ")) {
        parseConfidenceBlock(content, confidence);
        sections.push({
          title: currentTitle,
          content,
          confidence: 0.7,
          citations: [],
        });
      } else {
        sections.push({
          title: currentTitle,
          content,
          confidence: 0.7,
          citations: [],
        });
      }
    }
  };

  // Match section headers: "### TITLE", "## TITLE", "# TITLE", "**TITLE**",
  // or "TITLE:" on its own line, or "TITLE" in all caps on its own line.
  for (const line of lines) {
    // "### TITLE" or "## TITLE" or "# TITLE"
    let m = line.match(/^#{1,6}\s+(.+?)\s*#*\s*$/);
    if (!m) {
      // "**TITLE**" or "** TITLE **"
      m = line.match(/^\*\*\s*(.+?)\s*\*\*\s*$/);
    }
    if (!m) {
      // "TITLE:" where TITLE is short and the line has no other content
      const colonMatch = line.match(/^([А-ЯЁA-Z][А-ЯЁA-Z0-9\s\/\(\)\-]{2,60}):\s*$/);
      if (colonMatch && !line.includes("  ")) {
        m = colonMatch;
      }
    }
    if (m) {
      flush();
      currentTitle = m[1].trim();
      currentBody = [];
    } else {
      currentBody.push(line);
    }
  }
  flush();

  // If no sections were found but there's content, treat the whole thing as
  // a single "Заключение" section so the UI has something to render.
  if (sections.length === 0 && cleaned.length > 0) {
    sections.push({
      title: "Заключение",
      content: cleaned.slice(0, 3000),
      confidence: 0.5,
      citations: [],
    });
  }

  if (!conclusion && sections.length > 0) {
    // v2.3.2: Prefer the "Диагноз" section, then "Резюме", else the first section
    const diagnosis = sections.find((s) =>
      s.title.toUpperCase().includes("ДИАГНОЗ") || s.title.toUpperCase().includes("DIAGNOSIS")
    );
    const summary = sections.find((s) =>
      s.title.toUpperCase().includes("РЕЗЮМЕ") || s.title.toUpperCase().includes("SUMMARY")
    );
    conclusion = (diagnosis ?? summary ?? sections[0]).content.slice(0, 1200);
  }
  if (!conclusion) {
    conclusion = cleaned.slice(0, 2000);
  }

  return { sections, conclusion, confidence };
}

function parseConfidenceBlock(text: string, out: Record<string, number>): void {
  const lines = text.split(/\r?\n/);
  for (const line of lines) {
    const m = line.match(/([а-яёa-z]+)\s*[:：]\s*([0-9]*\.?[0-9]+)/i);
    if (m) {
      const keyMap: Record<string, string> = {
        диагноз: "diagnosis", diagnosis: "diagnosis",
        терапия: "therapy", therapy: "therapy",
        прогноз: "prognosis", prognosis: "prognosis",
        общая: "overall", overall: "overall",
      };
      const mapped = keyMap[m[1].toLowerCase()] ?? m[1].toLowerCase();
      const val = parseFloat(m[2]);
      if (Number.isFinite(val)) {
        out[mapped] = val > 1 ? val / 100 : val;
      }
    }
  }
}
