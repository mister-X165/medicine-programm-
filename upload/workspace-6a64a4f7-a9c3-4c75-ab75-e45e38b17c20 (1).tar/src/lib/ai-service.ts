// СППВР — слой ИИ-инференса с graceful degradation (ТЗ п. 4.1, 5.1, 5.3)
// Приоритет провайдеров:
//   1. LM Studio (локальный OpenAI-compatible сервер) — основной, если настроен
//   2. Ручной режим — если LM Studio недоступен (ТЗ 5.3)
//
// Все вычисления выполняются локально (ФЗ-152 ст. 18 ч. 3): данные пациента
// не покидают рабочую станцию. Облачные провайдеры не используются.

import { logger } from "@/lib/logger";
import {
  getLMStudioConfig,
  lmStudioChat,
  lmStudioVision,
  checkLMStudioHealth,
} from "./lm-studio";

/**
 * Какой провайдер ИИ сейчас активен.
 *   "lm-studio" — LM Studio включён и отвечает
 *   "none"      — LM Studio недоступен (ручной режим)
 */
export async function getActiveProvider(): Promise<"lm-studio" | "none"> {
  const cfg = getLMStudioConfig();
  if (cfg.enabled) {
    const health = await checkLMStudioHealth();
    if (health.ok) return "lm-studio";
  }
  return "none";
}

/**
 * Комплексная проверка ИИ-ядра: LM Studio → none.
 * Для health-check возвращает статус и метаданные провайдера.
 */
export async function checkAIHealth(): Promise<{
  ok: boolean;
  error?: string;
  provider?: "lm-studio" | "none";
  lmStudioOk?: boolean;
  lmStudioError?: string;
  model?: string;
}> {
  // LM Studio (единственный провайдер)
  const cfg = getLMStudioConfig();
  let lmStudioOk = false;
  let lmStudioError: string | undefined;
  if (cfg.enabled) {
    const lmHealth = await checkLMStudioHealth();
    lmStudioOk = lmHealth.ok;
    lmStudioError = lmHealth.error;
    if (lmStudioOk) {
      return {
        ok: true,
        provider: "lm-studio",
        lmStudioOk: true,
        model: cfg.model,
      };
    }
  }

  // Ни один провайдер недоступен
  const parts: string[] = [];
  if (cfg.enabled) {
    parts.push(`LM Studio: ${lmStudioError}`);
  } else {
    parts.push("LM Studio не настроен (LM_STUDIO_URL не указан)");
  }
  return {
    ok: false,
    error: parts.join(" | "),
    provider: "none",
    lmStudioOk,
    lmStudioError,
  };
}

/**
 * LLM-запрос для текстового анализа (NER, заключения, RAG).
 * Приоритет: LM Studio → null (ручной режим).
 *
 * options.maxTokens позволяет увеличить лимит выходных токенов для длинных
 * заключений. Это критично для небольших моделей (напр. gemma-3-4b), которые
 * при дефолтном лимите 4096 токенов обрывают ответ на середине JSON.
 *
 * Встроена RETRY-логика: при пустом/коротком ответе запрос повторяется до 2 раз.
 * Это покрывает случаи обрыва streaming-соединения (модель сгенерировала часть,
 * но SSE-поток оборвался на середине).
 */
export async function llmChat(
  systemPrompt: string,
  userMessage: string,
  options?: { json?: boolean; temperature?: number; maxTokens?: number },
): Promise<string | null> {
  const maxRetries = parseInt(process.env.LM_STUDIO_MAX_RETRIES ?? "2", 10);

  // LM Studio (единственный провайдер) с retry
  const cfg = getLMStudioConfig();
  if (!cfg.enabled) {
    logger.warn("ai", "LLM запрос невозможен: LM Studio не настроен (ручной режим)");
    return null;
  }

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    const result = await lmStudioChat(systemPrompt, userMessage, options);
    if (result && result.trim().length > 0) {
      // Проверка минимальной полноты ответа — для JSON хотя бы 20 символов,
      // для plain-text хотя бы 50 (чтобы отсечь обрывы на "тера...")
      const minLen = options?.json ? 20 : 50;
      if (result.trim().length >= minLen) {
        return result;
      }
      logger.warn("ai", "LM Studio attempt: короткий ответ, retry", { attempt, length: result.length });
    } else {
      logger.warn("ai", "LM Studio attempt: пустой ответ, retry", { attempt });
    }
    if (attempt < maxRetries) {
      // Экспоненциальная задержка: 1с, 3с, 9с...
      const delayMs = 1000 * Math.pow(3, attempt - 1);
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  // LM Studio не дал валидного ответа после retry — ручной режим
  logger.warn("ai", "LM Studio: retry исчерпан, возврат в ручной режим");
  return null;
}

/**
 * VLM-анализ изображения (медицинские снимки). ТЗ п. 3.2.
 * Использует LM Studio с загруженной multimodal-моделью.
 * Возвращает null, если LM Studio недоступен или не имеет vision-модели.
 */
export async function vlmAnalyzeImage(
  imageDataUrl: string,
  question: string,
): Promise<string | null> {
  // LM Studio vision
  const cfg = getLMStudioConfig();
  if (cfg.enabled) {
    const result = await lmStudioVision(imageDataUrl, question);
    if (result !== null) return result;
  }
  return null;
}

/**
 * Безопасный парсинг JSON-ответа LLM (с очисткой от markdown).
 */
export function parseJSON<T>(raw: string | null): T | null {
  if (!raw) return null;
  let cleaned = raw.trim();
  // Удаление markdown-обёртки ```json ... ```
  const fence = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) cleaned = fence[1].trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    // Попытка найти первый { ... } или [ ... ]
    const objMatch = cleaned.match(/\{[\s\S]*\}/);
    if (objMatch) {
      try {
        return JSON.parse(objMatch[0]) as T;
      } catch {}
    }
    const arrMatch = cleaned.match(/\[[\s\S]*\]/);
    if (arrMatch) {
      try {
        return JSON.parse(arrMatch[0]) as T;
      } catch {}
    }
    return null;
  }
}
