// СППВР — клиент LM Studio (локальный OpenAI-compatible инференс).
// ТЗ п. 4.1: аналогия LM Studio API, но через прямой HTTP-вызов /v1/chat/completions.
//
// LM Studio поднимает OpenAI-совместимый сервер на http://127.0.0.1:1234/v1.
// Используется как ЕДИНСТВЕННЫЙ провайдер ИИ; при недоступности — ручной режим.
// Полностью локально (ФЗ-152): данные не покидают рабочую станцию.

import { logger } from "@/lib/logger";

export interface LMStudioConfig {
  enabled: boolean;
  baseUrl: string;
  model: string;
}

/**
 * Чтение конфигурации LM Studio из переменных окружения.
 * LM_STUDIO_URL — базовый URL (например, http://127.0.0.1:1234/v1)
 * LM_STUDIO_MODEL — идентификатор загруженной модели (например, "my model")
 *
 * Сервис считается включённым, если задан LM_STUDIO_URL. Если переменная
 * не задана, по умолчанию используется стандартный адрес LM Studio
 * (http://127.0.0.1:1234/v1) — это позволяет подключить LM Studio сразу,
 * без правки .env. Если сервер не отвечает — приложение переходит в ручной
 * режим без ошибок.
 */
export function getLMStudioConfig(): LMStudioConfig {
  // DEFAULT: стандартный адрес LM Studio. Подключает LM Studio сразу, без
  // необходимости явно прописывать LM_STUDIO_URL в .env.
  const DEFAULT_LM_STUDIO_URL = "http://127.0.0.1:1234/v1";
  const rawUrl = (process.env.LM_STUDIO_URL ?? "").trim();
  let baseUrl = (rawUrl.length > 0 ? rawUrl : DEFAULT_LM_STUDIO_URL).replace(/\/+$/, "");

  // v4.3 audit fix (SSRF defense): LM_STUDIO_URL must point to a localhost
  // address. A misconfigured env (or CI/CD injection) that points it at an
  // internal host (e.g. cloud metadata 169.254.169.254) would turn every LLM
  // call into an SSRF probe. Reject non-localhost hosts hard.
  try {
    const u = new URL(baseUrl);
    const ALLOWED_HOSTS = new Set(["127.0.0.1", "localhost", "::1"]);
    if (!ALLOWED_HOSTS.has(u.hostname)) {
      logger.error("lm-studio", `LM_STUDIO_URL hostname "${u.hostname}" is not localhost — refusing to use it (SSRF defense). Falling back to default.`);
      baseUrl = DEFAULT_LM_STUDIO_URL;
    }
  } catch {
    logger.error("lm-studio", `Invalid LM_STUDIO_URL "${rawUrl}" — falling back to default.`);
    baseUrl = DEFAULT_LM_STUDIO_URL;
  }

  const model = (process.env.LM_STUDIO_MODEL ?? "").trim();
  return {
    enabled: baseUrl.length > 0,
    baseUrl,
    model,
  };
}

interface LMChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface LMChatCompletionResponse {
  id?: string;
  choices?: Array<{
    index?: number;
    message?: { role?: string; content?: string };
    finish_reason?: string;
  }>;
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    total_tokens?: number;
  };
}

interface LMModelsResponse {
  object?: string;
  data?: Array<{
    id: string;
    object?: string;
    owned_by?: string;
  }>;
}

/**
 * Проверка доступности LM Studio — GET {baseUrl}/models.
 * Возвращает ok=true и список моделей, если сервер отвечает.
 */
export async function checkLMStudioHealth(): Promise<{
  ok: boolean;
  error?: string;
  models?: string[];
  latencyMs?: number;
}> {
  const cfg = getLMStudioConfig();
  if (!cfg.enabled) {
    return { ok: false, error: "LM_STUDIO_URL не задан" };
  }
  const started = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 3000);
  try {
    const res = await fetch(`${cfg.baseUrl}/models`, {
      method: "GET",
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json" },
    });
    if (!res.ok) {
      return {
        ok: false,
        error: `HTTP ${res.status} ${res.statusText}`,
        latencyMs: Date.now() - started,
      };
    }
    const data = (await res.json()) as LMModelsResponse;
    const models = (data.data ?? []).map((m) => m.id).filter(Boolean);
    return {
      ok: true,
      models,
      latencyMs: Date.now() - started,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return {
      ok: false,
      error: msg.includes("abort") ? "Тайм-аут (сервер не отвечает)" : msg,
      latencyMs: Date.now() - started,
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * LLM-запрос к LM Studio — POST {baseUrl}/chat/completions.
 * Совместимо с OpenAI Chat Completions API.
 *
 * ИСПОЛЬЗУЕТ STREAMING (stream: true) — это КРИТИЧЕСКИ важно для небольших
 * моделей (gemma-3-4b на CPU), которые генерируют длинные ответы (до 8K токенов)
 * по 5-10 минут. Без streaming HTTP-соединение разрывается по таймауту
 * (Caddy 30с, Next.js 60с, fetch 120с), и LM Studio логирует
 * "Client disconnected. Stopping generation..." — модель не успевает доделать.
 * При streaming токены поступают постоянно → соединение активное → модель
 * работает столько, сколько нужно.
 *
 * Возвращает строку-ответ или null при ошибке.
 */
export async function lmStudioChat(
  systemPrompt: string,
  userMessage: string,
  options?: { json?: boolean; temperature?: number; maxTokens?: number },
): Promise<string | null> {
  const cfg = getLMStudioConfig();
  if (!cfg.enabled) return null;

  const finalSystem = options?.json
    ? `${systemPrompt}\n\nВАЖНО: ответь ТОЛЬКО валидным JSON без markdown-обёртки.`
    : systemPrompt;

  const messages: LMChatMessage[] = [
    { role: "system", content: finalSystem },
    { role: "user", content: userMessage },
  ];

  // Таймаут 10 минут — gemma-3-4b на CPU может генерировать 8K токенов
  // до 5-8 минут. Streaming держит соединение активным, но abort-controller
  // нужен как предохранитель от зависаний.
  const timeoutMs = parseInt(process.env.LM_STUDIO_TIMEOUT_MS ?? "600000", 10);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);

  try {
    const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        // Запрос не кешировать — важно для streaming
        Accept: "text/event-stream",
      },
      body: JSON.stringify({
        model: cfg.model || "local-model",
        messages,
        temperature: options?.temperature ?? 0.2,
        max_tokens: options?.maxTokens ?? 4096,
        stream: true, // ← STREAMING: критично для длинных ответов на CPU
      }),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      logger.error("ai", "LM Studio chat HTTP error", { status: res.status, body: text.slice(0, 200) });
      return null;
    }

    if (!res.body) {
      // Сервер не поддерживает streaming — fallback к JSON-ответу
      const data = (await res.json()) as LMChatCompletionResponse;
      return data.choices?.[0]?.message?.content ?? null;
    }

    // Читаем SSE-поток (Server-Sent Events)
    // Формат OpenAI streaming: каждая строка "data: {json}\n\n", финал "data: [DONE]"
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let fullContent = "";
    let buffer = "";
    let lastActivity = Date.now();
    // Idle-таймаут: если 3 минуты нет новых токенов — прерываем (модель зависла)
    const idleTimeoutMs = parseInt(process.env.LM_STUDIO_IDLE_TIMEOUT_MS ?? "180000", 10);

    while (true) {
      // Проверка idle-таймаута (модель молчит)
      if (Date.now() - lastActivity > idleTimeoutMs) {
        logger.error("ai", "LM Studio idle timeout", { timeoutMs: idleTimeoutMs });
        break;
      }

      const { done, value } = await reader.read();
      if (done) break;

      lastActivity = Date.now();
      buffer += decoder.decode(value, { stream: true });

      // Обрабатываем все завершённые строки в буфере
      const lines = buffer.split("\n");
      buffer = lines.pop() || ""; // последняя неполная строка остаётся в буфере

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith("data:")) continue;
        const data = trimmed.slice(5).trim();
        if (data === "[DONE]") {
          return fullContent || null;
        }
        try {
          const parsed = JSON.parse(data) as {
            choices?: Array<{
              delta?: { content?: string };
              finish_reason?: string;
            }>;
          };
          const delta = parsed.choices?.[0]?.delta?.content;
          if (delta) {
            fullContent += delta;
          }
        } catch {
          // Частичный JSON — игнорируем, соберём из следующих чанков
        }
      }
    }

    return fullContent || null;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes("abort")) {
      logger.error("ai", "LM Studio chat timeout", { timeoutMs });
    } else {
      logger.error("ai", "LM Studio chat error", { error: msg });
    }
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * VLM-анализ изображения через LM Studio (если загружена multimodal-модель).
 * Совместимо с OpenAI Vision API: content = [{type:"text"}, {type:"image_url"}].
 * Использует streaming для поддержки длинных ответов.
 */
export async function lmStudioVision(
  imageDataUrl: string,
  question: string,
): Promise<string | null> {
  const cfg = getLMStudioConfig();
  if (!cfg.enabled) return null;

  const timeoutMs = parseInt(process.env.LM_STUDIO_TIMEOUT_MS ?? "600000", 10);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        Accept: "text/event-stream",
      },
      body: JSON.stringify({
        model: cfg.model || "local-model",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: question },
              { type: "image_url", image_url: { url: imageDataUrl } },
            ],
          },
        ],
        temperature: 0.2,
        max_tokens: 1024,
        stream: true,
      }),
    });
    if (!res.ok) {
      logger.error("ai", "LM Studio vision HTTP error", { status: res.status });
      return null;
    }
    if (!res.body) {
      const data = (await res.json()) as LMChatCompletionResponse;
      return data.choices?.[0]?.message?.content ?? null;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let fullContent = "";
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith("data:")) continue;
        const data = trimmed.slice(5).trim();
        if (data === "[DONE]") return fullContent || null;
        try {
          const parsed = JSON.parse(data) as {
            choices?: Array<{ delta?: { content?: string } }>;
          };
          const delta = parsed.choices?.[0]?.delta?.content;
          if (delta) fullContent += delta;
        } catch {}
      }
    }
    return fullContent || null;
  } catch (e) {
    logger.error("ai", "LM Studio vision error", { error: e instanceof Error ? e.message : String(e) });
    return null;
  } finally {
    clearTimeout(timer);
  }
}
