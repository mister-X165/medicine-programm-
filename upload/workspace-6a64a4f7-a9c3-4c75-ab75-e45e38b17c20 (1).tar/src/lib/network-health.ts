// СППВР v2.3 — Network Health & Circuit Breaker
// ============================================================================
// PURPOSE: Provide fault-tolerant network operations. When the internet is
// unavailable (DNS failure, connection refused, timeout), the system should:
//   1. Detect the outage quickly (don't hang for 15s per request)
//   2. Open a "circuit breaker" so subsequent requests fail fast
//   3. Return a clear "network unavailable" status to callers
//   4. Periodically probe (every 60s) to detect when connectivity returns
//   5. NEVER crash the request — always degrade gracefully
//
// This module is used by:
//   - web-rag.ts (DuckDuckGo search, NCBI E-utilities, article fetching)
//   - chat route (when AI is available, web RAG is triggered)
//   - analyze route (web RAG step 4.5)
//   - any future external API integration
//
// ARCHITECTURE:
//   - `networkStatus` holds the current state: { online, lastCheck, lastError }
//   - `checkNetwork()` does a quick HEAD request to a reliable endpoint
//   - `circuitBreaker` wraps any async fn: opens after N failures, half-opens
//     after a cooldown, closes on success
//   - `safeFetch()` is a drop-in replacement for fetch() that:
//       * respects the circuit breaker
//       * catches all network errors
//       * never throws (returns a typed error result instead)

import { logger } from "./logger";

// ---------------------------------------------------------------------------
// Network status — shared, mutable, in-memory
// ---------------------------------------------------------------------------

export interface NetworkStatus {
  online: boolean;
  lastCheck: number; // epoch ms
  lastError: string | null;
  consecutiveFailures: number;
  // When the circuit opened (epoch ms). null if closed.
  circuitOpenedAt: number | null;
}

const status: NetworkStatus = {
  online: true, // optimistic — assume online at startup
  lastCheck: 0,
  lastError: null,
  consecutiveFailures: 0,
  circuitOpenedAt: null,
};

// Endpoints we probe to check connectivity. We use DuckDuckGo's favicon
// (lightweight, fast) and Cloudflare's trace endpoint as fallback.
// These are chosen because they're highly available and don't require auth.
//
// v2.3.2 (Task 3): Added Z.AI API host as the FIRST probe endpoint.
// Z.AI (internal-api.z.ai) is the infrastructure used by the `z-ai-web-dev-sdk`
// fallback search provider. In sandboxed environments where duckduckgo.com and
// eutils.ncbi.nlm.nih.gov are BLOCKED but z.ai is REACHABLE, probing only
// DDG/NCBI would falsely report "network offline" and trip the circuit breaker.
// By probing z.ai first, the network status accurately reflects "online" when
// at least one search provider is reachable.
//
// v2.3.2 (Task 3): Z.AI host is added to PROBE_ENDPOINTS so the connectivity
// probe succeeds whenever z.ai is reachable — even if DDG/NCBI are blocked.
// v4.1: Probe endpoints reworked — the ONLY external knowledge source is
// the official Минздрав РФ CR repository (cr.minzdrav.gov.ru). The probe
// targets its backend API host directly so connectivity detection matches
// the actual dependency of the web RAG.
const PROBE_ENDPOINTS = [
  "https://cr.minzdrav.gov.ru/", // Минздрав РФ CR public site (light static page)
  "https://apicr.minzdrav.gov.ru/api.ashx?op=GetNkoList", // Минздрав РФ CR API (light endpoint)
  // v4.3 audit fix: removed the z.ai infra probe. A medical CDSS deployed in
  // a Russian hospital must not make outbound calls to z.ai infrastructure.
  // The only external knowledge source is the Минздрав CR repository.
];

// v2.3.2 (Task 3): Hosts that BYPASS the circuit breaker entirely.
// Z.AI SDK calls use their own managed infrastructure (internal-api.z.ai)
// which is independent from DuckDuckGo/NCBI. If DDG/NCBI are blocked but
// z.ai is reachable, we must NOT let DDG/NCBI failures open the circuit
// and block z.ai calls. `safeFetch()` checks this list and skips the
// circuit-breaker wrapper for matching hosts (still applies a timeout,
// still catches errors — just doesn't trip the global circuit).
//
// Хосты, которые обходят circuit breaker: вызовы через z-ai-web-dev-sdk
// используют собственную инфраструктуру Z.AI, независимую от DDG/NCBI.
// v4.1: Минздрав РФ hosts (apicr.minzdrav.gov.ru, cr.minzdrav.gov.ru,
// rosminzdrav.ru) bypass the circuit breaker — they are the PRIMARY and
// ONLY external knowledge source. Their unavailability must not be masked
// by a circuit opened by other failures, and their failures must not block
// other traffic. Z.AI hosts remain for infra calls.
const BYPASS_CIRCUIT_HOSTS = [
  "apicr.minzdrav.gov.ru", // backend API официального репозитория КР Минздрава
  "cr.minzdrav.gov.ru", // публичный сайт репозитория КР
  "minzdrav.gov.ru", // Минздрав РФ
  "rosminzdrav.ru", // Минздрав РФ (зеркало)
  // v4.3 audit fix: removed z.ai hosts — no longer a dependency.
];

/**
 * Check if a URL's host is in the circuit-breaker bypass whitelist.
 * Used by `safeFetch` to skip circuit-breaker logic for Z.AI hosts.
 * Returns true if the host should bypass the circuit breaker.
 */
export function isBypassHost(url: string): boolean {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    return BYPASS_CIRCUIT_HOSTS.some(
      (h) => host === h || host.endsWith("." + h),
    );
  } catch {
    return false;
  }
}

let probeInProgress = false;
// v2.3.1: All circuit-breaker timings are configurable via .env so operators
// can tune the system for their network conditions.
const PROBE_INTERVAL_MS = parseInt(process.env.NETWORK_PROBE_INTERVAL_MS ?? "60000", 10);
const PROBE_TIMEOUT_MS = parseInt(process.env.NETWORK_PROBE_TIMEOUT_MS ?? "5000", 10);

/**
 * Check if we have network connectivity. This is a QUICK check:
 *   - If we recently checked and were online, return cached `true` without
//     a network call (avoids latency on every request).
//   - If we recently checked and were offline, and the cooldown hasn't
//     elapsed, return cached `false` (fail-fast).
//   - Otherwise, do a real probe.
 */
export async function checkNetwork(): Promise<boolean> {
  const now = Date.now();
  const sinceLastCheck = now - status.lastCheck;

  // If online and checked recently (< 30s ago), trust the cached state
  if (status.online && sinceLastCheck < 30_000) {
    return true;
  }

  // If offline and the re-probe interval hasn't elapsed, fail fast
  if (!status.online && sinceLastCheck < PROBE_INTERVAL_MS) {
    return false;
  }

  // Don't start a probe if one is already in progress
  if (probeInProgress) {
    return status.online;
  }

  probeInProgress = true;
  try {
    const online = await probeNetwork();
    if (online !== status.online) {
      logger.info("network", `Network status changed: ${status.online ? "online" : "offline"} → ${online ? "online" : "offline"}`, {
        previousError: status.lastError,
      });
    }
    status.online = online;
    status.lastCheck = now;
    if (online) {
      status.consecutiveFailures = 0;
      status.lastError = null;
      status.circuitOpenedAt = null;
    } else {
      status.consecutiveFailures++;
      status.lastError = status.lastError || "Network probe failed";
      if (status.circuitOpenedAt === null) {
        status.circuitOpenedAt = now;
      }
    }
    return online;
  } finally {
    probeInProgress = false;
  }
}

/**
 * Get the current network status (without triggering a probe).
 * Useful for the health endpoint and UI status badges.
 */
export function getNetworkStatus(): NetworkStatus {
  return { ...status };
}

/**
 * Mark a network operation as failed. This increments the failure counter
 * and may open the circuit breaker. Used by `safeFetch` and callers that
 * want to report a network failure without doing a full probe.
 */
export function reportNetworkFailure(error: string): void {
  status.consecutiveFailures++;
  status.lastError = error;
  status.lastCheck = Date.now();
  // Open the circuit after the configured threshold of consecutive failures
  const threshold = parseInt(process.env.NETWORK_CIRCUIT_FAILURE_THRESHOLD ?? "3", 10);
  if (status.consecutiveFailures >= threshold && status.circuitOpenedAt === null) {
    status.online = false;
    status.circuitOpenedAt = Date.now();
    logger.warn("network", "Circuit opened — network marked offline", {
      consecutiveFailures: status.consecutiveFailures,
      threshold,
      error,
    });
  }
}

/**
 * Mark a network operation as successful. This resets the failure counter
 * and closes the circuit breaker.
 */
export function reportNetworkSuccess(): void {
  if (status.consecutiveFailures > 0 || !status.online) {
    logger.info("network", "Network recovered — circuit closed", {
      previousFailures: status.consecutiveFailures,
    });
  }
  status.consecutiveFailures = 0;
  status.online = true;
  status.lastError = null;
  status.circuitOpenedAt = null;
  status.lastCheck = Date.now();
}

/**
 * Quick connectivity probe. Tries each probe endpoint in order; returns
 * true on the first successful response.
 */
async function probeNetwork(): Promise<boolean> {
  for (const endpoint of PROBE_ENDPOINTS) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), PROBE_TIMEOUT_MS);
    try {
      const res = await fetch(endpoint, {
        method: "GET",
        signal: ctrl.signal,
        headers: {
          "User-Agent": "СППВР/2.3 (health-check)",
          Accept: "text/html,application/json,*/*;q=0.8",
        },
        // Don't follow redirects for the probe — we just want to know if
        // the host is reachable.
        redirect: "manual" as RequestRedirect,
      });
      // Any HTTP response (even 3xx/4xx/5xx) means we have connectivity.
      // Only network-level failures (DNS, connection refused, timeout) mean
      // we're offline.
      if (res.status > 0) {
        return true;
      }
    } catch {
      // Try the next endpoint
    } finally {
      clearTimeout(timer);
    }
  }
  return false;
}

// ---------------------------------------------------------------------------
// Circuit breaker — wraps an async function
// ---------------------------------------------------------------------------

export interface CircuitBreakerOptions {
  /** Open the circuit after this many consecutive failures. Default: 3 */
  failureThreshold?: number;
  /** After opening, wait this long before trying again (half-open). Default: 60s */
  cooldownMs?: number;
  /** Operation name for logging. */
  name?: string;
}

export interface CircuitBreakerResult<T> {
  ok: boolean;
  value?: T;
  error?: string;
  circuitOpen?: boolean;
}

/**
 * Wrap an async function in a circuit breaker. When the circuit is open
 * (too many recent failures), the function is NOT called and a
 * `circuitOpen: true` result is returned immediately. This prevents
 * cascading failures and avoids hanging on unreachable endpoints.
 *
 * Usage:
 *   const result = await withCircuitBreaker(
 *     () => fetchExternalData(),
 *     { name: "duckduckgo-search" }
 *   );
 *   if (result.ok) { ... result.value ... }
 *   else { ... result.error ... } // includes circuitOpen flag
 */
export async function withCircuitBreaker<T>(
  fn: () => Promise<T>,
  options: CircuitBreakerOptions = {},
): Promise<CircuitBreakerResult<T>> {
  // v2.3.1: defaults read from .env (NETWORK_CIRCUIT_FAILURE_THRESHOLD,
  // NETWORK_CIRCUIT_COOLDOWN_MS) so operators can tune without code changes.
  const failureThreshold = options.failureThreshold ?? parseInt(process.env.NETWORK_CIRCUIT_FAILURE_THRESHOLD ?? "3", 10);
  const cooldownMs = options.cooldownMs ?? parseInt(process.env.NETWORK_CIRCUIT_COOLDOWN_MS ?? "60000", 10);
  const name = options.name ?? "operation";

  // Check if the circuit is open
  if (status.consecutiveFailures >= failureThreshold) {
    const sinceOpen = Date.now() - (status.circuitOpenedAt ?? status.lastCheck);
    if (sinceOpen < cooldownMs) {
      // Circuit is open and cooldown hasn't elapsed — fail fast
      return {
        ok: false,
        error: `Сетевой модуль недоступен (circuit open). Последняя ошибка: ${status.lastError ?? "неизвестно"}`,
        circuitOpen: true,
      };
    }
    // Cooldown elapsed — try a half-open probe
    logger.info("network", `Circuit half-open — probing for ${name}`, {
      sinceOpenMs: sinceOpen,
    });
    const online = await checkNetwork();
    if (!online) {
      return {
        ok: false,
        error: `Сетевой модуль недоступен (нет интернет-соединения). Последняя ошибка: ${status.lastError ?? "неизвестно"}`,
        circuitOpen: true,
      };
    }
  }

  // Circuit is closed (or half-open probe succeeded) — call the function
  try {
    const value = await fn();
    reportNetworkSuccess();
    return { ok: true, value };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    // Distinguish network errors from application errors
    const isNetworkError = isNetworkErrorLike(e);
    if (isNetworkError) {
      reportNetworkFailure(msg);
    }
    logger.warn("network", `Circuit breaker caught error in ${name}`, {
      error: msg,
      isNetworkError,
      consecutiveFailures: status.consecutiveFailures,
    });
    return { ok: false, error: msg };
  }
}

/**
 * Heuristic: does this error look like a network-level failure (as opposed
 * to an application-level error like a 404 or 500)?
 */
function isNetworkErrorLike(e: unknown): boolean {
  if (!(e instanceof Error)) return false;
  const msg = e.message.toLowerCase();
  // Common network error signatures
  if (msg.includes("fetch failed")) return true;
  if (msg.includes("enotfound")) return true; // DNS
  if (msg.includes("econnrefused")) return true;
  if (msg.includes("econnreset")) return true;
  if (msg.includes("etimedout")) return true;
  if (msg.includes("eai_again")) return true; // DNS temporary failure
  if (msg.includes("aborted")) return true; // our timeout
  if (msg.includes("network")) return true;
  if (msg.includes("undici")) return true; // Node fetch internals
  // TypeError: fetch failed (Node 18+ undici)
  if (e instanceof TypeError && msg.includes("fetch")) return true;
  return false;
}

// ---------------------------------------------------------------------------
// safeFetch — drop-in replacement for fetch() that never throws
// ---------------------------------------------------------------------------

export interface SafeFetchResult {
  ok: boolean;
  response?: Response;
  error?: string;
  circuitOpen?: boolean;
  fromCache?: boolean;
}

/**
 * A safe wrapper around fetch() that:
 *   1. Checks the network circuit breaker BEFORE making the request
 *   2. Catches all network errors (never throws)
 *   3. Reports failures to the circuit breaker
 *   4. Returns a typed result so callers can handle both cases cleanly
 *
 * If the circuit is open, returns immediately without a network call.
 *
 * v2.3.2 (Task 3): Hosts in BYPASS_CIRCUIT_HOSTS (e.g. internal-api.z.ai)
 * SKIP the circuit-breaker check entirely. Z.AI SDK infrastructure is
 * independent from DuckDuckGo/NCBI — DDG/NCBI failures must not block Z.AI
 * calls. We still apply the timeout and catch errors; we just don't trip
 * the global circuit breaker for these hosts.
 *
 * Хосты из белого списка (z.ai) обходят circuit breaker — их сбои не
 * размыкают цепь, т.к. инфраструктура Z.AI независима от DDG/NCBI.
 */
export async function safeFetch(
  url: string,
  options?: RequestInit & { timeoutMs?: number },
): Promise<SafeFetchResult> {
  const timeoutMs = options?.timeoutMs ?? 15_000;
  const { timeoutMs: _omit, ...fetchOptions } = options ?? {};

  // v2.3.2 (Task 3): Bypass circuit breaker for whitelisted hosts (Z.AI).
  // These hosts use their own infrastructure and must not be affected by
  // DDG/NCBI outages. We still enforce a timeout and catch errors.
  if (isBypassHost(url)) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        ...fetchOptions,
        signal: ctrl.signal,
      });
      return { ok: true, response };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      logger.warn("network", `Bypass-host fetch failed (no circuit trip): ${new URL(url).hostname}`, {
        error: msg,
      });
      return { ok: false, error: msg };
    } finally {
      clearTimeout(timer);
    }
  }

  const result = await withCircuitBreaker(
    async () => {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      try {
        const response = await fetch(url, {
          ...fetchOptions,
          signal: ctrl.signal,
        });
        return response;
      } finally {
        clearTimeout(timer);
      }
    },
    { name: `fetch:${new URL(url).hostname}` },
  );

  if (result.ok) {
    return { ok: true, response: result.value };
  }
  return {
    ok: false,
    error: result.error,
    circuitOpen: result.circuitOpen,
  };
}
