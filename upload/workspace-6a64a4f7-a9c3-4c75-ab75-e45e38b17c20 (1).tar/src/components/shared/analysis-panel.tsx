"use client";

import * as React from "react";
import {
  AlertTriangle,
  Dna,
  FileText,
  Image as ImageIcon,
  BookOpen,
  Quote,
  Loader2,
  Cpu,
  Hand,
  TrendingUp,
  ShieldAlert,
  ShieldCheck,
  Pill,
  Activity,
  Code,
  History,
  Stethoscope,
  Landmark,
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { AnalysisResultData, Citation, DDIAlert, ICD10CodeMatch, ClinicalPathwayMatch } from "@/lib/types";
import { api } from "@/lib/api";
import { useAppStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn, formatDateTime } from "@/lib/utils";
import { VersionHistoryDialog } from "@/components/shared/version-history-dialog";

const MIN_REASON_LENGTH = 10;

/**
 * Strip markdown formatting from text so it displays as plain text.
 * Removes: **bold**, *italic*, ### headings, `code`, ~~strike~~, [link](url),
 * markdown list markers (-, *, 1.), and excessive whitespace.
 * This prevents the "****" artifacts the user reported.
 */
function stripMarkdown(text: string): string {
  if (!text) return "";
  return text
    // Remove markdown code fences ```...```
    .replace(/```[\s\S]*?```/g, (m) => m.replace(/```/g, "").trim())
    // Remove bold **text** or __text__
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/__(.+?)__/g, "$1")
    // Remove italic *text* or _text_ (but not standalone * as bullet)
    .replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, "$1")
    .replace(/(?<!_)_(?!_)(.+?)(?<!_)_(?!_)/g, "$1")
    // Remove strikethrough ~~text~~
    .replace(/~~(.+?)~~/g, "$1")
    // Remove inline code `text`
    .replace(/`(.+?)`/g, "$1")
    // Remove markdown links [text](url) → text
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    // Remove heading markers ### at start of lines
    .replace(/^#{1,6}\s+/gm, "")
    // Remove markdown list markers at start of lines (-, *, +, 1.)
    .replace(/^[\s]*[-*+]\s+/gm, "• ")
    .replace(/^[\s]*\d+\.\s+/gm, "")
    // Remove horizontal rules ---
    .replace(/^---+$/gm, "")
    // Remove blockquote markers >
    .replace(/^>\s+/gm, "")
    // Collapse multiple blank lines
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

interface Props {
  analysis: AnalysisResultData;
  caseId: string;
  onRunAnalysis: (manual: boolean) => void;
  isAnalyzing: boolean;
  hasDocuments: boolean;
}

export function AnalysisPanel({ analysis, caseId, onRunAnalysis, isAnalyzing, hasDocuments }: Props) {
  const [activeCitation, setActiveCitation] = React.useState<string | null>(null);
  const [versionHistoryOpen, setVersionHistoryOpen] = React.useState(false);

  const confidence = analysis.confidence ?? {};
  const sections = analysis.sections ?? [];
  const mutations = analysis.mutations ?? [];
  const recommendations = analysis.recommendations ?? [];
  const citations = analysis.citations ?? [];
  const imageFindings = analysis.imageFindings ?? [];
  const icd10Suggestions = analysis.icd10Suggestions ?? [];
  const pathwayMatches = analysis.pathwayMatches ?? [];

  const handleCitationClick = (cit: Citation) => {
    setActiveCitation(cit.claim);
    setTimeout(() => setActiveCitation(null), 3000);
  };

  // Version history button: enabled only when there are at least 2 versions
  // to compare. The analysis.version counter starts at 1 (initial analysis),
  // and each re-run snapshots the prior state and bumps the counter — so
  // analysis.version >= 2 implies at least one historical snapshot exists.
  const currentVersion = analysis.version ?? 1;
  const canCompareVersions = currentVersion >= 2;

  return (
    <div className="space-y-4">
      {/* Panel header: version history entry point */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border bg-card/50 px-3 py-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Cpu className="h-4 w-4 text-emerald-600" aria-hidden />
          <span className="font-medium text-foreground">Анализ</span>
          <Badge
            variant="outline"
            className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
          >
            v{currentVersion}
          </Badge>
        </div>
        <Tooltip>
          <TooltipTrigger asChild>
            <span tabIndex={0} aria-label="История версий анализа">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                disabled={!canCompareVersions}
                onClick={() => setVersionHistoryOpen(true)}
                aria-label="Открыть историю версий анализа"
              >
                <History className="h-4 w-4" aria-hidden />
                История версий
                {canCompareVersions && (
                  <Badge
                    variant="secondary"
                    className="ml-1 bg-emerald-500/15 text-xs text-emerald-700 dark:text-emerald-400"
                  >
                    {currentVersion}
                  </Badge>
                )}
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            {canCompareVersions
              ? `Доступно версий: ${currentVersion}. Нажмите, чтобы сравнить.`
              : "Запустите анализ повторно, чтобы создать новую версию для сравнения."}
          </TooltipContent>
        </Tooltip>
      </div>

      {/* Conclusion — enhanced with diagnosis highlight */}
      <Card className="overflow-hidden border-l-4 border-l-primary">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="h-4 w-4 text-primary" />
              Заключение
            </CardTitle>
            <Badge className="bg-medical-gradient text-white">ИИ-анализ</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Diagnosis highlight — extract ICD-10 code and diagnosis from conclusion */}
          {(() => {
            const diagnosisMatch = analysis.conclusion.match(/(Основной диагноз|Диагноз)[:\s]*([^\n]+)/i);
            const icdMatch = analysis.conclusion.match(/\b([A-Z]\d{2}(?:\.\d{1,4})?)\b/g);
            const icdCodes = icdMatch ? Array.from(new Set(icdMatch)).slice(0, 4) : [];
            if (diagnosisMatch || icdCodes.length > 0) {
              return (
                <div className="rounded-lg border border-primary/20 bg-medical-gradient-soft p-3">
                  <div className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-primary">
                    <Stethoscope className="h-3.5 w-3.5" />
                    Установленный диагноз
                  </div>
                  {diagnosisMatch && (
                    <div className="text-sm font-medium leading-snug text-foreground">
                      {stripMarkdown(diagnosisMatch[2].trim().replace(/\(.*?\)/g, "").trim())}
                    </div>
                  )}
                  {icdCodes.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {icdCodes.map((code, i) => (
                        <Badge key={i} variant="outline" className="border-sky-500/30 bg-sky-500/10 font-mono text-[10px] text-sky-700 dark:text-sky-300">
                          {code}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              );
            }
            return null;
          })()}
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-foreground">{stripMarkdown(analysis.conclusion)}</p>
        </CardContent>
      </Card>

      {/* Confidence levels */}
      {Object.keys(confidence).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" />
              Степень уверенности модели
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(confidence).map(([key, val]) => (
              <div key={key}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="capitalize text-muted-foreground">{translateConfidenceKey(key)}</span>
                  <span className="font-medium">{Math.round((val as number) * 100)}%</span>
                </div>
                <Progress
                  value={(val as number) * 100}
                  className={cn(
                    "h-2",
                    (val as number) >= 0.7 && "[&>div]:bg-emerald-500",
                    (val as number) >= 0.4 && (val as number) < 0.7 && "[&>div]:bg-amber-500",
                    (val as number) < 0.4 && "[&>div]:bg-red-500",
                  )}
                />
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Sections with citations */}
      {sections.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Quote className="h-4 w-4 text-primary" />
              Структурированное заключение
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-[600px] space-y-4 overflow-y-auto pr-1 -mr-1">
              {sections.map((section, idx) => (
                <div key={idx} className="rounded-lg border p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <h4 className="text-sm font-semibold">{section.title}</h4>
                    <Badge variant="outline" className="text-xs">{Math.round(section.confidence * 100)}% уверенность</Badge>
                  </div>
                  <div className="whitespace-pre-wrap text-sm leading-relaxed text-foreground">{stripMarkdown(section.content)}</div>
                  {section.citations && section.citations.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {section.citations.map((citOrId: string | Citation, ci: number) => {
                        const cit = typeof citOrId === "string"
                          ? citations.find((c) => c.claim === citOrId)
                          : citOrId;
                        if (!cit) return null;
                        return (
                          <button
                            key={ci}
                            onClick={() => handleCitationClick(cit)}
                            className={cn(
                              "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs transition-colors hover:bg-accent",
                              activeCitation === cit.claim && "border-primary bg-primary/10",
                            )}
                          >
                            <Quote className="h-3 w-3" />
                            {cit.claim.slice(0, 40)}
                            {cit.claim.length > 40 && "…"}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mutations + Recommendations */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Dna className="h-4 w-4 text-emerald-600" />
              Генетические варианты
              <Badge variant="secondary" className="ml-auto">{mutations.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {mutations.length > 0 ? (
              <div className="max-h-80 overflow-y-auto pr-1 -mr-1">
                <div className="space-y-2">
                  {mutations.map((m, i) => (
                    <div key={i} className="rounded-lg border p-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-semibold">{m.gene}</span>
                        <span className="text-xs text-muted-foreground">{m.variant}</span>
                        <Badge variant="outline" className={cn("ml-auto text-xs", sigColor(m.clinicalSignificance))}>
                          {sigLabel(m.clinicalSignificance)}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">{m.interpretation}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Варианты не выявлены</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BookOpen className="h-4 w-4 text-primary" />
              Клинические рекомендации (RAG)
              <Badge variant="secondary" className="ml-auto">{recommendations.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recommendations.length > 0 ? (
              <div className="max-h-80 overflow-y-auto pr-1 -mr-1">
                <div className="space-y-2">
                  {recommendations.map((r, i) => (
                    <div key={i} className="rounded-lg border p-2.5">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-sm font-medium">{r.title}</span>
                        <Badge variant="outline" className="shrink-0 text-xs">{Math.round(r.relevanceScore * 100)}%</Badge>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        {r.gene && <span className="font-mono font-medium text-emerald-600">{r.gene}</span>}
                        <span>{r.source}</span>
                        {r.evidenceLevel && <Badge variant="secondary" className="text-xs">ур. {r.evidenceLevel}</Badge>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Релевантные рекомендации не найдены</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* NEW: DDI Alerts */}
      <DDIAlertsCard caseId={caseId} alerts={analysis.ddiAlerts ?? []} />

      {/* NEW: ICD-10 Codes */}
      {icd10Suggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Code className="h-4 w-4 text-primary" />
              МКБ-10 коды
              <Badge variant="secondary" className="ml-auto">{icd10Suggestions.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {icd10Suggestions.map((code, i) => (
                <div key={i} className="rounded-lg border p-2.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-semibold text-primary">{code.code}</span>
                    <Badge variant="outline" className="text-xs">{Math.round(code.confidence * 100)}%</Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{code.description}</p>
                  <Badge variant="secondary" className="mt-1 text-[10px]">{code.source === "ai" ? "ИИ" : "Вручную"}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* NEW: Clinical Pathways */}
      {pathwayMatches.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="h-4 w-4 text-primary" />
              Клинические пути
              <Badge variant="secondary" className="ml-auto">{pathwayMatches.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-96 overflow-y-auto pr-1 -mr-1">
              <div className="space-y-2">
                {pathwayMatches.map((pathway, i) => (
                  <div key={i} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{pathway.name}</span>
                      <Badge variant="outline" className="text-xs">{Math.round(pathway.matchScore * 100)}% совпадение</Badge>
                    </div>
                    {pathway.icd10Code && (
                      <p className="mt-1 text-xs text-muted-foreground">МКБ-10: {pathway.icd10Code}</p>
                    )}
                    <p className="mt-1 text-xs text-muted-foreground">Категория: {pathway.category}</p>
                    {pathway.steps.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {pathway.steps.map((step, si) => (
                          <div key={si} className="flex items-start gap-2 text-xs">
                            <span className="mt-0.5 shrink-0 text-primary font-mono">{step.order}.</span>
                            <div>
                              <span className="font-medium">{step.title}</span>
                              <span className="text-muted-foreground"> — {step.description}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Image findings */}
      {imageFindings.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <ImageIcon className="h-4 w-4 text-purple-600" />
              Анализ изображений
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-96 space-y-2 overflow-y-auto pr-1 -mr-1">
              {imageFindings.map((f, i) => (
                <div key={i} className="rounded-lg border p-3">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Снимок #{i + 1}</span>
                    <SuspicionBadge level={f.suspicion} />
                  </div>
                  <p className="text-sm">{f.description}</p>
                  {f.measurements && <p className="mt-1 text-xs text-muted-foreground">Размеры: {f.measurements}</p>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* XAI Citations */}
      {citations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Quote className="h-4 w-4 text-primary" />
              Цитаты-источники (XAI)
              <Badge variant="secondary" className="ml-auto">{citations.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-96 overflow-y-auto pr-1 -mr-1">
              <div className="space-y-2">
                {citations.map((cit, i) => {
                  const isMinzdrav = cit.source === "web_rag" || (cit.location || "").includes("minzdrav");
                  const sourceLabel = isMinzdrav
                    ? "КР Минздрава РФ"
                    : cit.source === "recommendation"
                      ? "Локальная база"
                      : cit.source === "document"
                        ? "Документ"
                        : cit.source;
                  return (
                  <button
                    key={i}
                    onClick={() => handleCitationClick(cit)}
                    className={cn(
                      "w-full rounded-lg border p-3 text-left transition-colors hover:bg-accent/50",
                      activeCitation === cit.claim && "border-primary bg-primary/5",
                      isMinzdrav && "border-teal-500/30 bg-teal-500/5",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Quote className="h-4 w-4 shrink-0 text-muted-foreground" />
                      {isMinzdrav ? (
                        <Badge variant="outline" className="gap-1 border-teal-500/40 bg-teal-500/10 text-teal-700 dark:text-teal-400">
                          <Landmark className="h-3 w-3" />
                          {sourceLabel}
                        </Badge>
                      ) : (
                        <span className="text-xs font-medium text-muted-foreground">{sourceLabel}</span>
                      )}
                      {cit.location && <span className="ml-auto max-w-[45%] truncate text-xs text-muted-foreground" title={cit.location}>{cit.location}</span>}
                    </div>
                    <p className="mt-1.5 text-sm font-medium">{cit.claim}</p>
                    {cit.fragment && <p className="mt-1 line-clamp-4 border-l-2 border-teal-500/40 pl-2 text-xs text-muted-foreground">{cit.fragment}</p>}
                  </button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Re-run analysis */}
      <div className="flex justify-center">
        <Button variant="outline" onClick={() => onRunAnalysis(false)} disabled={isAnalyzing || !hasDocuments} className="gap-2">
          {isAnalyzing ? <><Loader2 className="h-4 w-4 animate-spin" /> Анализ выполняется…</> : <><Cpu className="h-4 w-4" /> Повторить анализ</>}
        </Button>
      </div>

      {/* Version history dialog */}
      <VersionHistoryDialog
        caseId={caseId}
        currentVersion={currentVersion}
        open={versionHistoryOpen}
        onOpenChange={setVersionHistoryOpen}
      />
    </div>
  );
}

// ===========================================================================
// DDI Alerts Card with Override support
// ===========================================================================
// v2.1: Each alert card has an "Отменить" (Override) button that opens a
// dialog where the doctor writes a clinical justification (min 10 chars).
// On submit, the override is persisted via POST /api/cases/[id]/ddi-override
// and an audit log entry is written. Overridden alerts show a green
// "Отменено" badge with the reason, doctor name and timestamp.
// ===========================================================================

function DDIAlertsCard({ caseId, alerts }: { caseId: string; alerts: DDIAlert[] }) {
  // Local copy of alerts so the UI updates instantly on override without
  // waiting for the case query to refetch.
  const [localAlerts, setLocalAlerts] = React.useState<DDIAlert[]>(alerts);
  React.useEffect(() => {
    setLocalAlerts(alerts);
  }, [alerts]);

  const [overrideTarget, setOverrideTarget] = React.useState<DDIAlert | null>(null);
  const [reason, setReason] = React.useState("");
  const qc = useQueryClient();
  const { currentDoctor } = useAppStore();

  const overrideMut = useMutation({
    mutationFn: (vars: { drug1: string; drug2: string; reason: string }) =>
      api.overrideDDIAlert(caseId, vars),
    onSuccess: (res, vars) => {
      // Optimistically update local state so the badge appears immediately.
      setLocalAlerts((prev) =>
        prev.map((a) =>
          a.drug1 === vars.drug1 && a.drug2 === vars.drug2
            ? { ...a, override: res.alert.override }
            : a,
        ),
      );
      toast.success("DDI-предупреждение отменено", {
        description: "Обоснование записано в журнал аудита.",
      });
      setOverrideTarget(null);
      setReason("");
      // Invalidate the case query so the server truth is reloaded.
      qc.invalidateQueries({ queryKey: ["case", caseId] });
    },
    onError: (e: Error) => {
      toast.error("Не удалось отменить предупреждение", {
        description: e.message,
      });
    },
  });

  if (localAlerts.length === 0) return null;

  const handleSubmit = () => {
    if (!overrideTarget) return;
    if (reason.trim().length < MIN_REASON_LENGTH) return;
    overrideMut.mutate({
      drug1: overrideTarget.drug1,
      drug2: overrideTarget.drug2,
      reason: reason.trim(),
    });
  };

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setOverrideTarget(null);
      setReason("");
    }
  };

  return (
    <Card className="border-red-500/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ShieldAlert className="h-4 w-4 text-red-600" />
          Лекарственные взаимодействия (DDI)
          <Badge variant="destructive" className="ml-auto">{localAlerts.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="max-h-96 overflow-y-auto pr-1 -mr-1">
          <div className="space-y-2">
            {localAlerts.map((alert, i) => {
              const isOverridden = alert.override?.overridden === true;
              const doctorName =
                alert.override?.overriddenBy === currentDoctor?.id
                  ? currentDoctor?.fullName
                  : alert.override?.overriddenBy;
              return (
                <div
                  key={`${alert.drug1}-${alert.drug2}-${i}`}
                  className={cn(
                    "rounded-lg border p-3",
                    isOverridden
                      ? "border-emerald-500/40 bg-emerald-500/5"
                      : ddiSeverityBorder(alert.severity),
                  )}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <Pill
                      className={cn(
                        "h-4 w-4",
                        isOverridden ? "text-emerald-600" : "text-red-600",
                      )}
                    />
                    <span className="font-medium text-sm">
                      {alert.drug1} + {alert.drug2}
                    </span>
                    {isOverridden ? (
                      <Badge
                        variant="outline"
                        className="ml-auto text-xs bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
                      >
                        <ShieldCheck className="mr-1 h-3 w-3" />
                        Отменено
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className={cn("ml-auto text-xs", ddiSeverityColor(alert.severity))}
                      >
                        {ddiSeverityLabel(alert.severity)}
                      </Badge>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{alert.description}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    <strong>Механизм:</strong> {alert.mechanism}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    <strong>Рекомендация:</strong> {alert.management}
                  </p>

                  {isOverridden ? (
                    <div className="mt-2 rounded-md border border-emerald-500/30 bg-emerald-500/5 p-2">
                      <div className="flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                        <ShieldCheck className="h-3 w-3" />
                        Предупреждение отменено врачом
                      </div>
                      <p className="mt-1 text-xs text-foreground">
                        <strong>Обоснование:</strong> {alert.override?.overrideReason}
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Врач: {doctorName ?? "—"} ·{" "}
                        {alert.override?.overriddenAt
                          ? formatDateTime(alert.override.overriddenAt)
                          : "—"}
                      </p>
                    </div>
                  ) : (
                    <div className="mt-2 flex justify-end">
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-1.5"
                        onClick={() => {
                          setOverrideTarget(alert);
                          setReason("");
                        }}
                      >
                        <AlertTriangle className="h-3.5 w-3.5" />
                        Отменить предупреждение
                      </Button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>

      {/* Override Dialog */}
      <Dialog open={!!overrideTarget} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-red-600" />
              Отмена DDI-предупреждения
            </DialogTitle>
            <DialogDescription>
              Заполните клиническое обоснование. Минимум {MIN_REASON_LENGTH} символов.
              Обоснование будет сохранено в карточке анализа и записано в журнал аудита.
            </DialogDescription>
          </DialogHeader>

          {overrideTarget && (
            <div className="space-y-3">
              <div className="rounded-md border bg-muted/40 p-3 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">
                    {overrideTarget.drug1} + {overrideTarget.drug2}
                  </span>
                  <Badge
                    variant="outline"
                    className={cn("text-xs", ddiSeverityColor(overrideTarget.severity))}
                  >
                    {ddiSeverityLabel(overrideTarget.severity)}
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {overrideTarget.description}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="ddi-override-reason">
                  Клиническое обоснование отмены
                </Label>
                <Textarea
                  id="ddi-override-reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Напр.: Польза комбинированной терапии превышает риск взаимодействия; пациент находится под мониторингом МНО и функции почек…"
                  rows={5}
                  className="resize-y"
                  disabled={overrideMut.isPending}
                />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    {reason.trim().length < MIN_REASON_LENGTH
                      ? `Ещё ${MIN_REASON_LENGTH - reason.trim().length} симв.`
                      : "Обоснование готово"}
                  </span>
                  <span>{reason.length} симв.</span>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => handleOpenChange(false)}
              disabled={overrideMut.isPending}
            >
              Отмена
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={
                overrideMut.isPending ||
                reason.trim().length < MIN_REASON_LENGTH ||
                !overrideTarget
              }
              className="gap-2"
            >
              {overrideMut.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Сохранение…
                </>
              ) : (
                <>
                  <ShieldCheck className="h-4 w-4" />
                  Подтвердить отмену
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function sigColor(sig: string): string {
  const map: Record<string, string> = {
    pathogenic: "bg-red-500/15 text-red-700 dark:text-red-400",
    likely_pathogenic: "bg-orange-500/15 text-orange-700 dark:text-orange-400",
    vus: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
    likely_benign: "bg-blue-500/15 text-blue-700 dark:text-blue-400",
    benign: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
  };
  return map[sig] ?? map.vus;
}

function sigLabel(sig: string): string {
  const map: Record<string, string> = {
    pathogenic: "Патогенный",
    likely_pathogenic: "Вероятно патогенный",
    vus: "Неопределённый",
    likely_benign: "Вероятно доброкачественный",
    benign: "Доброкачественный",
  };
  return map[sig] ?? sig;
}

function ddiSeverityColor(severity: string): string {
  const map: Record<string, string> = {
    contraindication: "bg-red-500/15 text-red-700 dark:text-red-400",
    major: "bg-orange-500/15 text-orange-700 dark:text-orange-400",
    moderate: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
    minor: "bg-blue-500/15 text-blue-700 dark:text-blue-400",
  };
  return map[severity] ?? map.moderate;
}

function ddiSeverityBorder(severity: string): string {
  const map: Record<string, string> = {
    contraindication: "border-red-500/40 bg-red-500/5",
    major: "border-orange-500/40 bg-orange-500/5",
    moderate: "border-amber-500/40 bg-amber-500/5",
    minor: "border-blue-500/40 bg-blue-500/5",
  };
  return map[severity] ?? map.moderate;
}

function ddiSeverityLabel(severity: string): string {
  const map: Record<string, string> = {
    contraindication: "Противопоказание",
    major: "Значительное",
    moderate: "Умеренное",
    minor: "Незначительное",
  };
  return map[severity] ?? severity;
}

function SuspicionBadge({ level }: { level: string }) {
  const map: Record<string, { label: string; color: string }> = {
    low: { label: "Низкое подозрение", color: "text-emerald-600" },
    moderate: { label: "Умеренное подозрение", color: "text-amber-600" },
    high: { label: "Высокое подозрение", color: "text-red-600" },
  };
  const cfg = map[level] ?? map.low;
  return <Badge variant="outline" className={cn("text-xs", cfg.color)}>{cfg.label}</Badge>;
}

function translateConfidenceKey(key: string): string {
  const map: Record<string, string> = { diagnosis: "Диагноз", therapy: "Терапия", prognosis: "Прогноз" };
  return map[key] ?? key;
}
