// СППВР v2.6.2 — fail-safe .env recovery (Task: container recreate resilience)
// ============================================================================
// The sandbox container may be recreated with a default .env containing only
// DATABASE_URL. Server-side secrets (JWT_SECRET, ENCRYPTION_KEY) then go
// missing and every API route fails with 503 "Server misconfigured".
//
// This script runs BEFORE `next dev` (see package.json "dev" script):
//   • preserves existing valid secrets untouched;
//   • generates fresh 256-bit hex secrets for anything missing;
//   • never weakens validation in src/lib/env.ts (>= 64 chars, blacklist);
//   • prints a clear report to stdout.
//
// NOTE on data impact: E2EE patient data (enc:v1:) is encrypted client-side
// with the doctor's DEK — it does NOT depend on these server secrets and
// survives rotation. Only previously created encrypted backups become
// undecryptable after ENCRYPTION_KEY rotation (accepted trade-off, documented
// in worklog).
// ============================================================================

import { appendFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";

const ENV_PATH = new URL("../.env", import.meta.url).pathname;
const REQUIRED: Array<{ key: string; hint: string }> = [
  { key: "JWT_SECRET", hint: "auth session tokens" },
  { key: "ENCRYPTION_KEY", hint: "server-side storage/backup encryption" },
];

function parseEnv(raw: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of raw.split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
  return out;
}

function generateSecret(): string {
  // 64 hex chars = 256 bit entropy; meets MIN_SECRET_LENGTH (64) in env.ts.
  return randomBytes(32).toString("hex");
}

export function main(): void {
  if (!existsSync(ENV_PATH)) {
    writeFileSync(ENV_PATH, "DATABASE_URL=file:/home/z/my-project/db/custom.db\n");
  }

  const raw = readFileSync(ENV_PATH, "utf8");
  const parsed = parseEnv(raw);
  const missing = REQUIRED.filter((r) => !parsed[r.key] || parsed[r.key].length < 64);
  const weak = missing.filter((r) => parsed[r.key] && parsed[r.key]!.length < 64);

  if (missing.length === 0) {
    console.log("[ensure-env] all required secrets present — nothing to do");
    return;
  }

  const additions: string[] = [];
  for (const { key, hint } of missing) {
    const value = generateSecret();
    if (weak.some((w) => w.key === key)) {
      // Replace the weak line in-place instead of appending a duplicate key.
      const re = new RegExp(`^\\s*${key}\\s*=.*$`, "m");
      const updated = raw.replace(re, `${key}=${value}`);
      writeFileSync(ENV_PATH, updated);
      console.log(`[ensure-env] rotated weak ${key} (${hint}) → fresh 256-bit secret`);
    } else {
      additions.push(`${key}=${value}`);
      console.log(`[ensure-env] generated ${key} (${hint}) → fresh 256-bit secret`);
    }
  }

  if (additions.length > 0) {
    const prefix = raw.endsWith("\n") || raw.length === 0 ? "" : "\n";
    appendFileSync(ENV_PATH, `${prefix}${additions.join("\n")}\n`);
  }

  console.log("[ensure-env] .env is now valid (secrets ≥ 64 hex chars each)");
}

main();
